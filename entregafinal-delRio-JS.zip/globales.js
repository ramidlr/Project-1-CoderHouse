/* 
alumno: ramirodelrio 
proyecto: BEAUTYLIVE™ es una web interactiva para reservar servicios de belleza, cosmetologia y bienestar.
*/

//jQuery DOM LISTO:
$(document).ready(function () {
  console.log("El DOM esta listo");
});


//GLOBALES
const arrayUsuarios = [];
const arrayServicios = [];
const carrito = [];